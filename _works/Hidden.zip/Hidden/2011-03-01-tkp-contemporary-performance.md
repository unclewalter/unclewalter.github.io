---
layout: page
date: "March 2011"
image: "works/tkp.jpeg"
title: "TKP Contemporary Performance"
role: "Composer"
client: "La Trobe Theatre"
client_link: ""
teaser: "This short piece underscored a series of monologues that I and my group performed for a university assessment in first year. I suppose you could call this my first theatre soundtrack. Though since it wasn't a public performance, I figure it's best to put here."
frontpage: false

categories: 
  - theatre
  - soundtrack
---
This short piece underscored a series of monologues that I and my group performed for a university assessment in first year. I suppose you could call this my first theatre soundtrack. Though since it wasn't a public performance, I figure it's best to put here.