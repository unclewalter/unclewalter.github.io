---
layout: page
date: "September 2012"
image: "works/ddpr.jpeg"
title: "Down Dangerous Passes Road"
role: "Composer/Sound Designer"
client: "Grounded Astronaut Theatre"
client_link: "https://www.facebook.com/pages/Grounded-Astronaut-theatre/152812671441665"
teaser: "Three estranged brothers are brought together by tragedy. What happened to their father fifteen years ago, and why does it plague the siblings still? A look at the cruelness, brutality and tenderness that we’re capable of."
frontpage: true

categories: 
  - theatre
  - soundtrack
  - sound design
---
Written by Michel Marc Bouchard

Directed by Sean Scanlon

Assistant Director: Libbee King

Three estranged brothers are brought together by tragedy. What happened to their father fifteen years ago, and why does it plague the siblings still? A look at the cruelness, brutality and tenderness that we're capable of.